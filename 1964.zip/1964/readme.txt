1964 0.8.4 Readme
September 20, 2002


To Get The Most Out Of Your 1964, Read This:
============================================

For advanced users, read Advanced_Users.txt.

Visit http://1964emu.emulation64.com. There you will find the latest downloads of 1964 and additional links to the messageboards and faq's.


Requirements:
DirectX 8.x
PIII 600 MHz or comparable AMD Athlon Processor
Windows XP/NT/ME/98/2000
128MB RAM or better recommended


[ Graphics ]

The latest build of 1964 features a fast recompiling engine, which means that many games can be played at really nice speeds, but you're not going to enjoy it much with our OpenGL plugin. Since several n64 emus share a compatible plugin spec, you can mix and match plugins from other emulators. We recommend that you download Jabo's Direct3D plugin which is available with PJ64. Go to http://www.pj64.net and download pj64. The filename will be "plugin/Jabo_Direct3D.dll" or similar. You can take this dll file and place it in the plugin subfolder in "1964". Then, from the plugin menu, you can choose Jabo's plugin in 1964.


[ Audio and Input ]

When you first start 1964, the basic plugins will be used so that 1964 can start. If you have the requirements to run 1964 properly, choose Azimer Audio 0.30 for audio and NooTe_DI plugin, or NRage's plugin for input.


[ Rom Browser ]

If you do not see a list of games in your window when you start 1964, then your Rom Folder has not yet been configured. Go to File->Change Folder and browse for the path to your games. When the rom list refreshes, you can now easily choose a game from the window. By default, the Rom Browser is set to automatically update the folder path after you choose your first game from the "File->Load ROM...". After this, your Rom browser should be updated.


[ Cheats ]
For help with game cheats:
1. Refer to the "Cheat Codes" subfolder in your 1964 folder



[ What's new in 1964 0.8.4 ]
Too many to list. Visit 1964.emulation64.com for more information.


1964 Team is 
Rice and schibo - 1964 Development
< schibo@emulation64.com >
< rice1964@yahoo.com >

Cheats: Emu64 Cheats Staff < dsfarad@yahoo.com >
FAQs: Raymond, Bobbi (email N/A)
Input plugin, zip support: NooTe

For additional help, please visit the EmuTalk forums at http://www.emulation64.com

Also visit http://www.ngemu.com
http://www.hosthq.net/~emuxhaven/
http://www.emuhq.com/