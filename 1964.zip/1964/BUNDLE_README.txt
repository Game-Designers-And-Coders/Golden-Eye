*********************GoldenEye 007/Perfect Dark 1964 Bundle*********************

-------------------------------General Information------------------------------
Type................: Pre-configured 1964 Bundle for GoldenEye 007 and Perfect Dark


---------------------------------How to Install---------------------------------
� STEP 1: Extract the zip to your local disk. 1964 will not work correctly if you
  run it from within the zip.

� STEP 2: Run 1964.exe and open the Edit menu, then click User Options. Make sure
  that "Plugins" and "Game Saves" use default folder locations. If the boxes are
  unticked, tick both and click OK.

� STEP 3: Open the Plugins menu, then click the menu item named "Change Plugins".

- Video plugin: You can choose between three plugins (ordered from quickest to slowest)
  Jabo 1.5.2/1.6.1: Quick, but some effects (water) and team colors will not be emulated.
  Glide64: Slow, emulates nearly everything but has issues with split-screen multiplayer.
  Shunyuan's SoftGraphic: Pathetically slow, accurate RDP core from MESS project.

- Audio plugin: You can choose between two versions of Azimer's HLE Audio plugin.
  Version 0.60: Quicker audio response but stutters every 5 seconds.
  Version 0.56: Slower audio response but does not stutter.

- Input plugin: Use DarkMan's DInput for keyboard and mouse and use N-Rage for USB
  controllers. If there is no input plugins to choose from then you need to install
  DirectX (9.0c or later).

- RSP plugin: Enabling RSP will emulate GoldenEye's music more accurately, but Perfect
  Dark will not run at 60 frames per second if RSP is enabled. Enable RSP for GoldenEye
  and disable RSP for Perfect Dark.

� STEP 4: After the plugins have been chosen click OK.

� STEP 5: Open the File menu then click the menu item called "Change Folder". Select
  your ROM directory and click OK.

� STEP 6: Open the 1964 directory and run Mouse Injector.exe. Start GE/PD and press
  4 to toggle the Mouse Injector on/off.

� NOTE: If you would like to enable V-Sync and set anti-aliasing for Glide64, you
  will need to force it by creating a game profile for 1964 in your graphics
  control panel.

------------------------------------Controls------------------------------------
GAMEPLAY INPUT
WASD		- Movement
Enter		- Start
Q		- A button (Accept/Next Weapon)
E		- B button (Cancel/Use/Reload)
Mouse 1		- Z button (Fire)
Mouse 2		- R button (Aim)
Mouse Wheel	- Next/Previous Weapon
CTRL		- Crouch
Mouse 2+W/S	- Sniper Zoom-In/Zoom-Out
Arrows		- Analog stick (camspy/slayer)

EMULATOR HOTKEYS
F3		- Pause emulation (toggle)
F4		- Stop emulation
F5		- Quicksave
F7		- Quickload (may desync Mouse Injector)
F12		- Screenshot (saves to 1964 directory)
TAB		- Hide Mouse Cursor
LSHIFT+1..9	- Select State (the Windows Asterisk sound will play when state has changed)
CTRL+C		- Cheats (only in windowed mode)
CTRL+V		- Change graphics settings (only in windowed mode)
ALT+ENTER	- Fullscreen toggle
ALT+F4		- Closes 1964

INJECTION HOTKEYS
4		- Toggle Mouse Injection/Lock Mouse Cursor
5		- Mouse Sensitivity (+/-)
6		- Crosshair Movement (+/-)
7		- Invert Pitch
8		- Aim Mode (only for GE 60fps build)
CTRL+0		- Hide/Show Settings
+/-		- Edit Mouse Sensitivity/Crosshair Movement
CTRL+F9		- GE/PD difficulty preset (my personal settings)

Note: These controls have been setup for the 1.2 profile which can be set in
GoldenEye 007's and Perfect Dark's options menu. If you would prefer a different
control layout, please refer to the FAQ.

--------------------------------------Bugs--------------------------------------
� The Mouse Injector does not support Perfect Dark's camspy/slayer. To control
  the camspy or slayer, use the arrow keys.

� Avoid pressing ALT+TAB while in fullscreen. Instead, exit fullscreen and pause
  the game (Enter) and then minimize 1964.

� Try to avoid pressing CTRL+1-8. This will change the ROM's counter flag which
  will cause some timing glitches. If this does happen press CTRL+1.

� When Perfect Dark is running it can switch between 30/60 frames per second.
  The Mouse Injector has a PD speed-hack, which forces PD to run at 60fps. This
  will only trigger when the Mouse Injector detects PD is running at 30fps. There
  will be some situations when PD cannot be forced to run at 60fps. To minimize
  stutter, turn off the RSP plugin when playing PD (see plugins menu).

� Because of the overclock, slow motion effects and combat boost will not work in
  this emulator.

� If the Mouse Cursor is hidden while viewing the romlist press TAB.

� 1964 can randomly break and run excruciatingly slow and not respond to hotkeys.
  To 'fix' this forcefully close 1964 (ALT+F4) and reopen 1964.

---------------------------------------FAQ--------------------------------------
Q:  How do I change the controls?
A:  Click the Plugins menu in 1964, then click Input Settings. The C-buttons
    are binded to WASD, and A and B buttons are binded to Q and E.

Q:  Why is WASD binded to the C-Buttons instead of the Analog stick?
A:  The C-Buttons are a better representation of WASD than the Analog stick.

Q:  Why does my character look up when I press W?
A:  There are many possible causes to this problem. This can be fixed by starting the
    game and selecting any level. When you have spawned press Enter (start button).
    Once you're in the start menu keep pressing left until you see the controller options.

    GoldenEye 007: You should see a floating N64 controller. Just press Q (A key)
    and then down or up to select your control style. Set to 1.2 and everything
    should work.

    Perfect Dark: Enter the Control menu and press Q (A button) then select
    the 1.2 control style.

    GoldenEye 007 Multiplayer: Restart the game and enter the multiplayer menu.
    In the multiplayer menu, there is a menu item called "Control Style". Open
    the Control Style menu and select 1.2.

    Perfect Dark Multiplayer: Restart the game and enter the Combat Simulator menu.
    Once inside the Combat Simulator go to the Advanced Setup menu item. Press the
    right arrow once and now you should be at the Player Setup menu. Go to Control
    and set the control style to 1.2. The rest of the options are to your personal
    preference. Go back to the Player Setup menu (E by default) and go to Save Player.
    Select "Controller Pak 1" and save. Now you can start the multiplayer match and
    the controls should work correctly. If you want to load the player again, just
    go back to the Player Setup menu and select Load Player.

Q:  How do I change the screen resolution for 1964?
A:  Just click the Plugins menu in 1964, then click Video Settings. The GUI for
    Glide64 and Jabo are easy enough to use so you shouldn't have any problems
    finding the fullscreen resolution settings. I do not recommend changing any
    other options.

Q:  How do I make GoldenEye 007/Perfect Dark more difficult with the Mouse Injector?
A:  Turn off auto-aim, sight on-screen and ammo on-screen. If it is still too easy
    try the 007/Perfect Dark difficulty mode with my personal settings (CTRL+F9 to set).

Q:  How do I change the button for crouch?
A:  First close the Mouse Injector, then open your web browser and go to this site:
    https://web.archive.org/web/20131503504200/http://nehe.gamedev.net/article/msdn_virtualkey_codes/15009/

    Get the hex number for your wanted crouch key from above site. When you have found
    the hex number, convert the hex to decimal and open mouseinjector.ini. Replace the
    last number (default is 162) with your new number and save the file. So for example,
    if you wanted A to crouch you would change 162 to 65 and save mouseinjector.ini.

Q:  Can I run Perfect Dark at 60 frames per second without a mouse?
A:  You can by leaving the Mouse Injector running in the background without pressing 4.

Q:  I accidentally cleared my WASD profile, how do I restore it?
A:  Open the Plugins menu then click the menu item named "Input Settings".

    DarkMan's DInput: In the DInput settings, you can load the default keys for the
    currently selected profile. For Player 1, select the GE/PD profile and then click
    the default button, then click OK.

    N-Rage: In the N-Rage settings you can load a profile for a controller. Select
    controller 1 and click "Load Profile". A file explorer should appear. Go to the
    plugin directory. You should see the file called "WASD.cpf" in the window. Select
    it and click open. If you don't see a file called "WASD.cpf" manually type WASD.cpf
    into the file name input box and press enter.

Q:  What's the difference between this build and 1964 Ultrafast?
A:  Ultrafast is built upon the 1.1 core which is known to have compatibility issues
    with GoldenEye 007. The 0.8.5 core is more stable for GoldenEye 007 which is what
    this build is built on.

Q:  I changed some settings and now Jabo plugin runs slow. How do I fix this?
A:  You may have enabled "Copy framebuffer to RDRAM" under advance settings in Jabo.
    To fix this untick "Copy framebuffer to RDRAM" and click OK.

Q:  Why does my Perfect Dark ROM hack not run at 60fps?
A:  If 1964 does not recognize the ROM it will assume default settings which
    breaks ROM hacks. To fix this, right click the ROM in the romlist menu and open
    the ROM's properties and set the EEPROM size to 16KB.

Q:  Why does the Mouse Injector not support Perfect Dark's camspy/slayer?
A:  I haven't found a reliable method of detecting their memory location as of yet.

Q:  The Mouse Injector stutters a lot. Is this normal?
A:  Randomly, the video plugin will flip out and interfere with the Mouse Injector.
    Changing the video plugin will fix the problem.

Q:  The Mouse Injector responds sluggish to my mouse input. How do I make it quicker?
A:  Turn off V-Sync, Anti-Alias and Anisotropic Filtering for your video plugin.
    If this did not help, disable DEP for 1964.exe and Mouse Injector.exe (Google
    how to do this for your operating system). If the issue persists set your
    virus scanner to game mode or disable it altogether.

Q:  Why doesn't Perfect Dark have mouse aiming support like GoldenEye?
A:  I haven't been able to implement crosshair aiming without injection artifacts,
    so I will not include it for PD until I've found a method that is seamless and
    artifact-free.

Q:  Why doesn't crouch aiming work in GoldenEye?
A:  N-Rage clashes with the Mouse Injector when the player is crouching and aiming.
    This can be fixed by changing the input plugin to DInput and restarting 1964.

Q:  Why does Jabo insert a black border on the bottom of the screen for Perfect Dark?
A:  I suspect this is caused by Jabo's inaccurate emulation of the N64's Video Interface.
    Jabo does not accurately detect resolution changes so you'll get some instances
    of borders. You can manually override this in Jabo's Rom Settings tab (this is
    accessed by disabling the option "Hide Advance Settings") and set PD's emulated
    height to 220. While this will cause the game's introduction to be cropped, it
    will remove the bottom border for the rest of the game.

Q:  When I play GoldenEye there is 2 vertical lines on the edge of the screen, why?
Q:  Old analog televisions never showed a 1:1 of the video input and would always
    overscan (crop) by some percent. GoldenEye was optimized to only draw within
    the "safe area" of a CRT television, as the outer edge of the screen would
    have been cropped from overscan.

Q:  Why doesn't the European version of GoldenEye work with the Mouse Injector?
A:  1964 and the Mouse Injector have been designed to only work with the USA versions
    of GoldenEye and Perfect Dark (v1.1). Other regional versions are not supported.

Q:  Is there anyway to stop 1964 desynchronising while playing over Kaillera/AQZ?
A:  No, unfortunately 1964 is known for desynchronising issues with netplay.
    I would recommend using Mupen, which you can download at goldeneyeonline.com.

Q:  How do I disable mouse acceleration for the Mouse Injector?
A:  Turn off Enhance Pointer Precision for your mouse. To do this first go to your
    control panel and click on "Hardware and Sound", click "Mouse" then go to Pointer
    Options. Uncheck "Enhance Pointer Precision" and click OK.

Q:  Why doesn't the Mouse Injector support aim mode for my GoldenEye ROM hack?
A:  The Mouse Injector will not support aiming mode for GoldenEye if it detects
    custom weapons. A ROM hack with custom weapons would most likely mean the gun
    rotation table within the Mouse Injector will no longer be accurate. To prevent
    this, the Mouse Injector checks to see if the current ROM has custom weapons,
    and if true, will disable aim mode.

Q:  Is there anyway to bind the spacebar without crashing DarkMan's plugin?
A:  Yes, it is still possible to bind to space in DarkMan's input. Here is how I
    did it.

    Open the Plugins menu and then click Input settings. Click the Profile Editor
    button and then click the "GoldenEye 007/Perfect Dark" profile in the top left
    window. Search for the key you wish to bind to spacebar inside the buttons window.
    After you have found the key you want to bind, press the "Primary" button and
    then press spacebar twice. It should bind without crashing DarkMan's input.
    When you're finished, press the OK button to exit the Profile Editor, then
    press default to load your changes and click OK.

------------------------------------Changelog-----------------------------------
Extra - 2014/08/06
� Mouse Injector - Added ability to change the default crouch key (see FAQ for how-to)
� Mouse Injector - Added ability to disable aiming mode for GE (1964 60fps build only)
� Mouse Injector - Lock Settings now renamed to Hide/Show Settings
� Mouse Injector - Reduced Crosshair Movement default by 50%
� Special thanks to /vr/ for suggestions and input
Final - 2014/03/11
� Updated 1964.ini and Project64.rdb to support latest version of GoldenEye X
� Mouse Injector - Mouse Cursor now locks to where the mouse cursor is located upon enabling the injector
� Mouse Injector - Forces Perfect Dark to always run at 60 frames per second (1964 60fps build only)
� Mouse Injector - Replicated GoldenEye 007 aiming mode design (1964 60fps build only)
� Mouse Injector - New crouching system for GoldenEye 007 (fixed stuttering)
� Mouse Injector - Mouse Sensitivity precision set to 5% intervals
� Mouse Injector - Debug option removed from release build
� Mouse Injector - Added Lock Settings hotkey (CTRL+0)
� Mouse Injector - Tickrate option removed
� Added xinput1_3.dll (for N-Rage)
� Added DarkMan's DInput plugin to bundle
� Added more questions and answers to FAQ in readme
� Mouse Injector and GE-MP are now licensed under BSD
v1.5d - 2013/04/22
� Mouse Injector supports PD hoverbikes (works 99% of the time)
� Fixed GE-MP interface bug (countdown no longer switchable in client mode)
� Updated 1964.ini, Project64.rdb and Glide64.ini to support latest version of GoldenEye X
� Added Shunyuan's SoftGraphic plugin (based on accurate RDP core from MESS project)
� Mouse Injector limits crosshair moving beyond the default range for Y axis
� New profiles in GoldenEye 007 will use controller layout 1.2 by default
� Removed save option from Mouse Injector (autosaves on exit)
� Improved interface for GE-MP and Mouse Injector
� Added Mouse Wheel weapon selection macro
� Rewrote install guide and improved FAQ
� Cleaned up Mouse Injector code
� 1964 - Removed Reset button
� 1964 - Pressing TAB will hide Mouse Cursor
� 1964 - State Slot can only be changed using Left Shift + 1..9
v1.5c - 2013/01/31
� Mouse Injector uses GE-MP's memory scanning design
� Mouse Injector no longer supports PD hoverbikes
� Mouse Injector supports GE/PD ROM hacks
� GE-MP and Mouse Injector now support Project64 1.6 (official build)
� 1964 - Saves use country name instead of rom CRC
� 1964 - Video Speed Sync is reset upon start up
� 1964 - Counter flag default is 1
� 1964 - RDRAM default size is 8MB
v1.5b - 2012/11/19
� Added Mupen64Plus 1.99.5 support for GE-MP and Mouse Injector, as requested by user buvk
� Rewrote GE-MP and Mouse Injector's ROM detection
� Improved GE-MP round quit code
� Fixed many bugs and cleaned up code for Mouse Injector and GE-MP
� Mouse Injector no longer injects mouse if multiplayer menu is open or when round has finished
v1.5a - 2012/09/23
� Updated Mouse Injector to support latest version of GoldenEye X
� Updated 1964.ini, Project64.rdb and Glide64.ini to support latest version of GoldenEye X
� Updated N-Rage plugin to version 2.3c (latest)
� GE-MP - Version 0.5 released
� GE-MP - Improved hurt code
� GE-MP - Fixed glitch when player 2 exits menu
v1.5 - 2012/04/19
� GE-MP - Tickrate is quicker to change
� GE-MP - Reverted netcode changes (every packet is confirmed)
� GE-MP - Inventory is synced
� GE-MP - MWTGG and flag tag are now supported
� GE-MP - Weapon drops now synced (but not positions)
� GE-MP - Added spawn with PP7 feature
� GE-MP - Fixed random round exits
� GE-MP - Now supports custom weapon sets (and up to 10 weapons synced)
� GE-MP - Added tickrate rating system
� GE-MP - Fixed round quitting system for client (still crashes but not so frequently)
� GE-MP - Fixed connection display issues
� GE-MP - Server quits to menu when client has disconnected
� GE-MP - Added setup guide
v1.49 - 2012/04/17
� GE-MP - Only inject character data from other player
� GE-MP - Fixed round quitting system for client (still crashes, but not as common)
� GE-MP - Replaced tickrate range (5ms to 80ms)
� GE-MP - Now no longer confirms packet (checks for menu packets)
v1.48 - 2012/04/16
� GE-MP - Improved map detection
� GE-MP - Fixed LTK mode (now makes players have 0 hp)
� GE-MP - Freeze menu for server until client connects
� GE-MP - Removed ultra low ranges for tickrate (too many injections = crashed emulator)
� GE-MP - All characters unlocked by default
� GE-MP - MWTGG and flag tag still broken (working on inventory sync)
� Cleaned up Mouse Injector code comments
� Renamed readme to BUNDLE_README.txt
v1.47 - 2012/04/09
� Mouse Injector now pauses before closing automatically when emulator is not detected
� GE-MP - LTK mode now implemented
� GE-MP - Removed debug hotkey (left in by accident)
� Touched up readme, and renamed to "PLEASE_DON'T_READ_ME.txt"
v1.46 - 2012/04/06
� GE-MP - Viewing start menu in-game will not make other player open up start menu
� GE-MP - Optimized time sync message
� GE-MP and Mouse Injector can use both +/- keys on keyboard
v1.45 - 2012/04/01
� Renamed Multiplayer to GE-MP
� GE-MP - Fixed some issues with deaths not syncing
� GE-MP - Fixed some glitches when returning to menu
� GE-MP - Fixed glitch for score based time limits matches
� GE-MP - Added larger tickrate range
� Mouse Injector and GE-MP have new icons
v1.44 - 2012/03/30
� Multiplayer - No longer crashes players when returning to menu
� Multiplayer - Now streams input to emulator via multithreading
� Multiplayer - No longer has desynced gun models
� Multiplayer - Added no shields feature
� Multiplayer - Tickrate now controlled by server
v1.43 - 2012/03/29
� Released beta multiplayer client/server for GoldenEye 007 (source code is ugly)
� Fixed searching issue for Mouse Injector
v1.42 - 2012/03/19
� Cleaned up code errors (don't copy and paste code)
v1.41 - 2012/03/16
� Converted Mouse Injector to GNU99 (now compiled with MinGW)
� Changed version number of bundle
v1.4 - 2012/03/12
� Fixed some logic issues with the interface coding with Mouse Injector
v1.39 - 2012/03/07
� Fixed some logic bugs with Mouse Injector
� Fixed up some outdated notes in readme
v1.38 - 2012/02/29
� Rewrote Mouse Injector, with improved hoverbike scanning and fixed bugs
� Updated N-Rage input plugin to 2.3
� Included broken proof of concept multiplayer prototype
v1.37 - 2012/01/16
� Added Mupen64++ Beta 0.1.3.12 support, as requested by user buvk
v1.36 - 2012/01/11
� Replaced PistolGrip's build with stolen's 0.8.5 build
� Updated Mouse Injector to support stolen's 0.8.5 build
� Added overclocking mods to timer.c (thank you death--droid and RetroRalph)
� Fixed 1964 crash when pressing CTRL+A/CTRL+D/CTRL+S
� Replaced ugly 1964 icon with a new ugly icon
v1.35 - 2011/12/31
� Cleaned up code for Mouse Injector
� Restarted development on multiplayer client and server for GoldenEye 007
v1.34 - 2011/12/30
� Updated Glide64 to final version
� Fixed saving/loading logic bug related with currenteditingsway variable
v1.33 - 2011/12/27
� Fixed comment errors
� Fixed saving/loading logic bug related with currenteditingsensitivity variable
� Mouse Injector stops injecting when GoldenEye is paused
v1.32 - 2011/12/23
� Project64 support removed from Mouse Injector due to dynamic addresses (not static)
� Cleaned up some code and comments
v1.31 - 2011/12/16
� Mouse Injector now supports the popular emulator Project64 v1.6
� Mouse Injector source code cleaned up and in K&R style of C (thanks AStyle)
� Mouse Injector addresses are now emulator neutral
v1.3 - 2011/12/03
� Updated Glide64 to latest version (revision 266)
� Updated Glide64.ini and set hotkey to 0
� Released source code to Mouse Injector under GPL v2
� Included 1964 0.8.5 source code to bundle
v1.29 - 2011/11/09
� Improved Mouse Injector interface
� Increased editable range for gun sway (you're now able to disable gun sway)
v1.28 - 2011/11/03
� Removed poor quality texture pack from bundle
� Mouse Injector.exe not compressed with UPX (can give false virus warnings)
� Updated Glide64 to latest version (revision 254)
v1.27 - 2011/10/14
� Added latest version of N-Rage input plugin
� Updated Jabo DX8 video plugin to latest version (skies are rendered)
� Mouse Injector gun sway sensitivity now editable
� Multiplayer client/server abandoned (see FAQ)
� Dumped more cloned interpret display names for current textures
v1.26 - 2011/10/05
� Mouse Injector save design is updated (less buggy)
� Improved colors of Archives wall textures
� Cleaned up code
� Added weapon movement support to Mouse Injector
� Removed changelog.txt file and readded changelog into readme
� Dumped more cloned interpret display names for current textures
v1.25 - 2011/09/21
� Fixed bug where limit rate would be changed when changing sensitivity
� Added FAQ in readme
� Added save settings feature
� Fixed Perfect Dark multiplayer camera sweep from being movable
� Dumped more cloned interpret display names for current textures
� Created Archives wall textures
v1.24 - 2011/09/14
� Perfect Dark hoverbike is now mouse supported
� GoldenEye 007 tank is now mouse supported
� Fixed GoldenEye 007 map camera sweep from being movable
� GoldenEye 007 mouse support is 100% complete
� Dumped more cloned interpret display names for current textures
� Suspended development of plugin version
� Started development on multiplayer client and server for GoldenEye 007
v1.23 - 2011/09/09
� Fixed double injection bug
v1.22 - 2011/09/08
� Added GoldenEye X support to Mouse Injector
� Rewritten Mouse Injector (better injection design, less bugs)
� Improved guide
� Dumped more cloned interpret display names for current textures
v1.21 - 2011/09/01
� Created changelog.txt file
� Added reverse pitch option to Mouse Injector
� Improved readme
v1.2 - 2011/08/31
� Added console title
� Improved guide
� Dumped more cloned interpret display names for current textures
� F9 now supports Perfect Dark
� Updated Glide64 to latest version (quicker cloak effect rendering)
v1.19 - 2011/08/30
� Improved readme
� Dumped more cloned interpret display names for current textures
� Mouse locks at centre of screen instead of 600x600
v1.18 - 2011/08/29
� Added icon to Mouse Injector
� Dumped more cloned interpret display names for current textures
� Improved readme
v1.17 - 2011/08/15
� Improved readme
� Dumped more cloned interpret display names for current textures
� Started work on plugin edition of the Mouse Injector
� Fixed emulator issue with Perfect Dark playing at 120 frames per second
v1.16 - 2011/08/07
� Fixed interface bug
� Dumped more cloned interpret display names for current textures
v1.15 - 2011/08/04
� Improved interface
� Disable crouch when mouse is disabled
� Added debug mode
� Fixed GoldenEye 007 crosshair moving without any mouse movement
v1.14 - 2011/08/01
� Added XP support
� Dumped more cloned interpret display names for current textures
v1.13 - 2011/07/29
� Fixed Perfect Dark's Group 3 not found error
� Remade GoldenEye 007 sky texture (GoldenEye 007#22D9AAA5#3#1_all)
v1.12 - 2011/07/28
� Removed unfinished heads from texture pack
� Fixed some bugs with crouching (still needs a rewrite)
� Improved build date information
v1.11 - 2011/07/27
� Mouse Injector GoldenEye 007 menu sensitivity decreased
� Dumped more cloned interpret display names for current textures
� Inserted build version and date into interface
v1.1 - 2011/07/26
� Many bug fixes, including better crouching method for both games
� Included WIP texture pack
v1.0 - 2011/07/23
� First release with new Mouse Injector, rewritten in C++ by stolen
v0.9 - 2011/06/27
� Created GoldenEye 007 bundle with PistolGrip's 1964 build and Mouse Injector by uncle bone
v0.1 - 2011/06/27
� Nearly captured all the cloned interpret display names for current textures
v0.03 - 2011/01/24
� Dumped more interpret display names for textures
v0.02 - 2010/10/27
� Dumped more interpret display names for textures
v0.01 - 2010/10/25
� Changed version name system
� Fixed a few textures that were bug-ish with Glide64
v0.0.2 - 2010/10/22
� Fixed the sky (GoldenEye 007#22D9AAA5#3#1_all)
v0.0.1 - 2010/10/15
� All textures are placeholders that will be replaced with better, non-stolen textures
  in the future

---------------------------END USER LICENSE AGREEMENT---------------------------
PLEASE READ THIS LICENSE CAREFULLY BEFORE USING THE SOFTWARE. BY USING THE SOFTWARE,
YOU ARE AGREEING TO BE BOUND BY THE TERMS OF THIS LICENSE. IF YOU DO NOT AGREE
TO THE TERMS OF THIS LICENSE, PROMPTLY DELETE THE UNUSED SOFTWARE.

1. License. The application, demonstration, system and other software accompanying
this License, whether on disk, in read only memory, or on any other media (the
�Software�) and the related documentation are licensed, not sold, to you by
stolen and are subject to this License. The �Software� includes any files
delivered to you (via on-line transmission or otherwise) to �patch,� update or
otherwise modify the software program. You own the zip package on which the
Software is compressed but stolen retain title to the Software and
related documentation, and reserve all rights not expressly granted to you.
This License allows you to use the Software on as many computers as you wish,
and only run the Software off that hard drive, however you may participate in
a multiplayer configuration (such as in an Internet gaming room) with other
players. You may also transfer all your license rights in the Software, the
backup copy of the Software, the related documentation and a copy of this License
to another party, provided the other party reads and agrees to accept the terms
and conditions of this License and you retain no copies of the Software or related
documentation and materials.

2. Termination. This License is effective until terminated. You may terminate this
License at any time by destroying the Software and related documentation and all
copies thereof. This License will terminate immediately without notice from
stolen if you fail to comply with any provision of this License. Upon
termination you must destroy the Software and related documentation and all
copies thereof.

4. UNDER NO CIRCUMSTANCES (INCLUDING WITHOUT LIMITATION NEGLIGENCE), SHALL
STOLEN OR ITS LICENSORS BE LIABLE FOR ANY LOSS OF DATA, PROFITS (EVEN
IF ARISING IN THE NORMAL CAUSE OF EVENTS) AND/OR ANY INCIDENTAL, SPECIAL OR
CONSEQUENTIAL DAMAGES THAT RESULT FROM THE USE OR INABILITY TO USE THE SOFTWARE
OR RELATED DOCUMENTATION, EVEN IF STOLEN HAS BEEN ADVISED OF THE POSSIBILITY
OF SUCH DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF
LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES SO THE ABOVE LIMITATION OR
EXCLUSION MAY NOT APPLY TO YOU. In no event shall stolen�s total liability
to you for all damages, losses, and causes of action (in each case whether in
contract, tort (including negligence) or otherwise) exceed the amount paid by
you for the downloading of the Software. Nothing in this License shall be deemed
or construed as excluding or limiting stolen�s liability for personal
injury or deal arising from its negligence, fraudulent misrepresentation or any
other liability which cannot be excluded or limited by law.

5. Controlling Law and Severability. This License shall be governed by and
construed in accordance with English law. If for any reason a court of competent
jurisdiction finds any provision of this License, or a portion thereof, to be
unenforceable, that provision of the License shall be deemed replaced by such
valid and enforceable provision whose contents are as close as permissible to
those of the unenforceable provision so as to effect the intent of the parties,
and the remainder of this License shall continue in full force and effect. You
hereby agree to the non-exclusive jurisdiction of the English courts.

6. Complete Agreement. This License constitutes the entire agreement between the
parties with respect to the use of the Software and the related documentation,
and supersedes all prior or contemporaneous understandings or agreements, written
or oral, regarding such subject matter, No amendment to or modification of this
License will be binding unless in writing and signed by stolen.