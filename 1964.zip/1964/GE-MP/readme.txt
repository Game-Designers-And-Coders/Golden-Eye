GE-MP is a multiplayer P2P hack which allows 2 people to play GoldenEye 007 over the
internet. GE-MP was never finished, and more of a proof of concept demo to see what
could be possible with memory injection. Please do not expect a flawless multiplayer
match of GoldenEye. You will encounter issues and lots of crashes.

Here is how to use GE-MP (I'm going to assume you're using 1964+DInput in this guide):

Step 1. Start 1964 and run GoldenEye 007 (U). If you're having issues please follow
the guide in BUNDLE_README.txt

Step 2. Load the save file marked 007 (all levels/cheats/characters unlocked) and wait
in the multiplayer menu.

Step 3. If you are the client, you will need to open gemp.ini and input the server's
IP address and port.

Step 4. Open DInput's options and follow the steps below:

Server: Set P2's profile to (default) and hit clear. Set P1's controller to profile
GE/PD and hit default.

Client: Set P1's profile to (default) and hit clear. Set P2's controller to profile
GE/PD and hit default.

Step 5. When the controllers have been setup, you can start GE-MP.exe. When you have
finished setting up GE-MP options press 0 to start. When your opponent has connected
the in-game multiplayer menu title will change from OFFLINE to ONLINE.

Note: The lower the tickrate, the more keyframes. If the tickrate is too low, you
will timeout. It should be noted that DarkMan's DInput seems to ignore mouse wheel
input for player 2, so keep that in mind.

------------------------------ENET LICENSE AGREEMENT------------------------------

                    ENet is Copyright (c) 2002-2011 Lee Salzman

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in the
Software without restriction, including without limitation the rights to use, copy,
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the
following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.